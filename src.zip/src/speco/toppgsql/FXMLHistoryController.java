/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package speco.toppgsql;

import com.sun.javafx.scene.control.Properties;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.util.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import speco.cat.Tx;
import speco.cat.util.Log;
import speco.toppgsql.om.ModelPgStatActivityHistory;
import speco.toppgsql.om.PgStatActivityHistory;


/**
 * FXML Controller class
 *
 * @author adrian
 */
public class FXMLHistoryController implements Initializable{

    @FXML
    private TableView<PgStatActivityHistory> tableview2;
    @FXML
    private TableColumn<PgStatActivityHistory, Integer> pid2;
    @FXML
    private TableColumn<PgStatActivityHistory, String> rolname2;
    @FXML
    private TableColumn<PgStatActivityHistory, String> waitEventType2;
    @FXML
    private TableColumn<PgStatActivityHistory, String> waitEvent2;
    @FXML
    private TableColumn<PgStatActivityHistory, String> state2;
    @FXML
    private TableColumn<PgStatActivityHistory, String> query2;
    @FXML
    private TableColumn<PgStatActivityHistory, Float> cpu2;
   
    private Tx tx;
    private ModelPgStatActivityHistory modelPg;
    private List<PgStatActivityHistory> pgActivitys;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        modelPg = new ModelPgStatActivityHistory();
        System.out.println("init");
    }

    public void buscarActividades(String base) {
        try {
                System.out.println("buscar Actividades");
                tx = new Tx(base);
                pgActivitys = modelPg.retriveAllPgStatActivityHistory(0, tx);
                System.out.println(pgActivitys.size());
                ObservableList<PgStatActivityHistory> observableList = FXCollections.observableArrayList(pgActivitys);
                pid2.setCellValueFactory(new PropertyValueFactory<>("pid"));
                query2.setCellValueFactory(new PropertyValueFactory<>("query"));
                rolname2.setCellValueFactory(new PropertyValueFactory<>("usename"));
                waitEvent2.setCellValueFactory(new PropertyValueFactory<>("wait_event"));
                waitEventType2.setCellValueFactory(new PropertyValueFactory<>("wait_event_type"));
                state2.setCellValueFactory(new PropertyValueFactory<>("state"));
                cpu2.setCellValueFactory(new PropertyValueFactory<>("cpu_user_seconds"));
                tableview2.setItems(observableList);
               // obtenerMetricaCpu();
        } catch (Exception ex) {
            Log.error(ex);
        }

    }
    
 
    /*private Float obtenerMetricaCpu() {
        Float totalCpu=0.0;
        for (PgStatActivityHistory s: pgActivitys){
            totalCpu += s.getCpu_system_seconds() + s.getCpu_user_seconds();
           // series.getData().add(new XYChart.Data<>(s.getSnapshot_time().toString(), totalCpu));
        }
        return totalCpu;
    }*/
    
    public void showActivity(String base){
        System.out.println("show");
        buscarActividades(base);
    }
    
}
