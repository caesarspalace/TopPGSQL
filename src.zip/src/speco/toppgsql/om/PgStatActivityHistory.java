package speco.toppgsql.om;


import speco.cat.om.Om;
import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;
import java.util.Date;
import java.sql.Timestamp;
import java.sql.Clob;
import java.sql.Blob;
/** TYPEADO POR EL GOMO */
public class PgStatActivityHistory extends Om implements Serializable {

    private Timestamp snapshot_time = null;
    private Integer pid = null;
    private String usename = null;
    private String datname = null;
    private String state = null;
    private String wait_event_type = null;
    private String wait_event = null;
    private Float cpu_user_seconds = null;
    private Float cpu_system_seconds = null;
    private Integer query_id = null;
    private String query = null;

    public PgStatActivityHistory() {
        setPk(null);
        setSqlRoi("true");
        setWhere(null);
        setOrderBy(null);
    }

    public Timestamp getSnapshot_time() {
        return snapshot_time;
    }

    public void setSnapshot_time(Timestamp snapshot_time) {
        this.snapshot_time = snapshot_time;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getUsename() {
        return usename;
    }

    public void setUsename(String usename) {
        this.usename = usename;
    }

    public String getDatname() {
        return datname;
    }

    public void setDatname(String datname) {
        this.datname = datname;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getWait_event_type() {
        return wait_event_type;
    }

    public void setWait_event_type(String wait_event_type) {
        this.wait_event_type = wait_event_type;
    }

    public String getWait_event() {
        return wait_event;
    }

    public void setWait_event(String wait_event) {
        this.wait_event = wait_event;
    }

    public Float getCpu_user_seconds() {
        return cpu_user_seconds;
    }

    public void setCpu_user_seconds(Float cpu_user_seconds) {
        this.cpu_user_seconds = cpu_user_seconds;
    }

    public Float getCpu_system_seconds() {
        return cpu_system_seconds;
    }

    public void setCpu_system_seconds(Float cpu_system_seconds) {
        this.cpu_system_seconds = cpu_system_seconds;
    }

    public Integer getQuery_id() {
        return query_id;
    }

    public void setQuery_id(Integer query_id) {
        this.query_id = query_id;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public Timestamp getsnapshot_time() {
        return this.snapshot_time;
    }

    public void setsnapshot_time(Timestamp snapshot_time) {
        this.snapshot_time = snapshot_time;
    }

    public Integer getpid() {
        return this.pid;
    }

    public void setpid(Integer pid) {
        this.pid = pid;
    }

    public String getusename() {
        return this.usename;
    }

    public void setusename(String usename) {
        this.usename = usename;
    }

    public String getdatname() {
        return this.datname;
    }

    public void setdatname(String datname) {
        this.datname = datname;
    }

    public String getstate() {
        return this.state;
    }

    public void setstate(String state) {
        this.state = state;
    }

    public String getwait_event_type() {
        return this.wait_event_type;
    }

    public void setwait_event_type(String wait_event_type) {
        this.wait_event_type = wait_event_type;
    }

    public String getwait_event() {
        return this.wait_event;
    }

    public void setwait_event(String wait_event) {
        this.wait_event = wait_event;
    }

    public Float getcpu_user_seconds() {
        return this.cpu_user_seconds;
    }

    public void setcpu_user_seconds(Float cpu_user_seconds) {
        this.cpu_user_seconds = cpu_user_seconds;
    }

    public Float getcpu_system_seconds() {
        return this.cpu_system_seconds;
    }

    public void setcpu_system_seconds(Float cpu_system_seconds) {
        this.cpu_system_seconds = cpu_system_seconds;
    }

    public Integer getquery_id() {
        return this.query_id;
    }

    public void setquery_id(Integer query_id) {
        this.query_id = query_id;
    }

    public String getquery() {
        return this.query;
    }

    public void setquery(String query) {
        this.query = query;
    }

}
